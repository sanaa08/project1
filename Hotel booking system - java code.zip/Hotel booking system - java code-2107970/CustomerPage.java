import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

 class CustomerPage {
    //private AbstractButton button1;//implements ActionListener {
    //public static void main(String[] args ) {
     public CustomerPage() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel();
        label.setText("Welcome");
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);

        panel.setBackground(new Color(100, 200, 255));
        Border border = BorderFactory.createLineBorder(Color.white, 10);
        panel.setBorder(border);
        panel.add(label);

        JFrame frame = new JFrame();
        frame.setTitle("Customer Page");
        frame.setSize(400, 400);
        frame.getContentPane().setBackground(new Color(100, 200, 255));
        frame.add(panel);
        //frame.add(label);

        panel.setLayout(null);

        JButton button = new JButton("Make booking");
        button.setBounds(100, 100, 200, 50);
        //button.addActionListener(new ViewBookings());
        panel.add(button);

        JButton button1 = new JButton("View booking");
        button1.setBounds(100, 150, 200, 50);
        //button1.addActionListener(new login1());
        panel.add(button1);

        JButton button2 = new JButton("Cancel booking");
        button2.setBounds(100, 200, 200, 50);
        //button2.addActionListener(new login1());
        panel.add(button2);

        frame.setVisible(true);

        buttonActions(button, button1, button2);

     }
        private void buttonActions(AbstractButton button, AbstractButton button1, JButton button2) {

        button.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
              dispose();
              new MakeBooking();

           }
        });

        button1.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
              dispose();
              new ViewBookings();
           }
        });

           button2.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
                 dispose();
                 new CancelBooking();
              }
           });


    }

    private void dispose() {
    }
    }



