import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LaunchPage implements ActionListener {
    JFrame frame = new JFrame();
    JButton myButton = new JButton("Register");
    JButton myButton1 = new JButton("Login");
    JPanel panel = new JPanel();
    JLabel label = new JLabel();

    LaunchPage(int customerId) {

        label.setText("Wellcome!");

        ImageIcon image = new ImageIcon("/Users/sanatabaku/IdeaProjects/HBSdemo/src/img.png");
        Border border = BorderFactory.createLineBorder(new Color(100, 200, 255), 20);
        label.setIcon(image);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(new Color(240, 240, 240));
        label.setFont(new Font("Serif", Font.PLAIN, 23));
        label.setIconTextGap(-25);
        label.setOpaque(true);
        label.setBorder(border);
        panel.add(label);

        myButton.setBounds(100, 300, 200, 50);
        myButton.setFocusable(false);
        myButton.addActionListener((ActionListener) this);


        myButton1.setBounds(300, 300, 200, 50);
        myButton1.setFocusable(false);
        myButton1.addActionListener((ActionListener) this);

        label.add(myButton);
        label.add(myButton1);

        frame.setTitle("Hotel Booking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(580, 430);
        frame.getContentPane().setBackground(new Color(100, 200, 255));
        frame.add(panel);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);



        /*frame.add(myButton);
        frame.add(label);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,420);
        frame.setLayout(null);
        frame.setVisible(true);*/

    }

    private void buttonActions() {
        myButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new NewWindow();
            }
        });

        myButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new login1();
            }
        });



    /*@Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==myButton) {
            frame.dispose();
            NewWindow myWindow = new NewWindow();
        }


        if (e.getSource()==myButton1) {
            frame.dispose();
            login1 mylogin1 = new login1();
        }*/

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
