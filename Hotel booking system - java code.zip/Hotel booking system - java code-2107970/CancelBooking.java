//Imports everything needed
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CancelBooking extends JFrame//Shows is a JFrame
{
    //Declaring JLabels, JTextFields, JComboBoxes
    JLabel lblUEMail = null;
    JLabel lblFn = null;
    JLabel lblLn = null;
    JLabel lblMobile = null;

    JTextField txtUEMail = null;
    JTextField txtFn = null;
    JTextField txtLn = null;
    JTextField txtMobile = null;

    private Integer customerId;
    //Declaring JButtons
    JButton btnLog, btnBack, btnEdit = null;
    //The following is declaring variables to be used to connect to the database
    //The variables are taken from the JDBC demos provided and changed to suit our needs
    Database database = new Database();
    Connection conn = null;
    Statement statement = null;
    ResultSet resultSet = null;

    public CancelBooking()//Constructor for EditAccount
    {//Uses a lot of stuff from the RegPage
        Database database = new Database();

        this.customerId = customerId;
        //this.role = role;
        //Declares label values and textbox lengths
        lblFn = new JLabel("First Name:");
        lblFn.setForeground(Color.white);
        lblLn = new JLabel("Last Name:");
        lblLn.setForeground(Color.white);
        lblUEMail = new JLabel("EMail:");
        lblUEMail.setForeground(Color.white);
        lblMobile = new JLabel("Mobile No:");
        lblMobile.setForeground(Color.white);

        //Declares more text boxes

        txtFn = new JTextField(20);
        txtLn = new JTextField(20);
        txtUEMail = new JTextField(20);
        txtMobile = new JTextField(20);

        btnEdit = new JButton("Update Details");
        btnBack = new JButton("Cancel booking");
        //Making the container and setting as a flowlayout
        Container con = getContentPane();
        con.setBackground(new Color(100, 200, 255));
        con.setLayout(new FlowLayout());
        //The following adds the appropriate components to the screen depending on
        //what type of user account is being edited
        con.add(lblFn);
        con.add(txtFn);
        con.add(lblLn);
        con.add(txtLn);
        con.add(lblUEMail);
        con.add(txtUEMail);
        con.add(lblMobile);
        con.add(txtMobile);

        //adds the buttons to the container
        con.add(btnBack);
        con.add(btnEdit);

        //Packs, sets inital size and makes JFrame visible
        pack();
        setSize(280,350);
        setVisible(true);
        fillData();//Calls function fillData to fill the text fields

        btnBack.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //Redirects users to where they came from
               // CustomerMainDemo redirect = new CustomerMainDemo(customerId);
                dispose();

            }
        });
        btnEdit.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                dispose();
                new MakeBooking();
                setData();//calls function setData to commit the changes to database
            }
        });
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Cancel your booking");

                dispose();
                new launchPageDemo();
            }
        });

    }

    public void fillData(){//Function to fill the textboxes with previous information
        try{

            database.statement = database.conn.createStatement();//Get all data from whichever type being edited that matches the username
            database.resultSet = database.statement.executeQuery("SELECT * FROM customer WHERE " +  "CustomerID = \"" + customerId + "\"");

            while (database.resultSet.next()) {//Fill the text fields appropriate
                txtFn.setText(database.resultSet.getString("FirstName"));
                txtLn.setText(database.resultSet.getString("LastName"));
                txtUEMail.setText(database.resultSet.getString("EMail"));
                txtMobile.setText(database.resultSet.getString("MobileNo"));


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public void setData()//Function to commit changes to database
    {
        try{


            database.statement = database.conn.createStatement();//Commit changes to the Student table entry where the username is the same
            database.statement.executeUpdate("UPDATE Customer SET Title = \"" +  "\", FirstName = \"" +
                    txtFn.getText() + "\", LastName = \"" + txtLn.getText() + "\", EMail  = \"" + txtUEMail.getText() +
                    "\", MobileNo = \"" + txtMobile.getText() + "\", Password  = \"" +
                    "\",Address1  = \"" +
                    "\",Town  = \"" +
                    "\",County  = \"" +
                    "\", PostCode  = \"" +

                    "\" WHERE CustomerID = \"" +
                    customerId + "\"");

        }
        catch (SQLException s){
            System.out.println("SQL statement is not executed!");//For testing purposes
            s.printStackTrace();
        }




    }
}
