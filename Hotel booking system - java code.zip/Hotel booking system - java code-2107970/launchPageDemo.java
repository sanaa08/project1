import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class launchPageDemo extends JFrame {
    private JLabel label = new JLabel();
    private JPanel panel = new JPanel();
    private JButton myButton;
    private JButton myButton1;


    private Integer customerId;
    private String role;

    public launchPageDemo() {
        setLayout(new FlowLayout());

        this.customerId = customerId;
        this.role = role;

        //Declaring a container for the components

        Container con = getContentPane();
        label.setText("Wellcome!");

        ImageIcon image = new ImageIcon("/Users/sanatabaku/IdeaProjects/HBSdemo/src/img.png");
        Border border = BorderFactory.createLineBorder(new Color(100, 200, 255), 20);
        label.setIcon(image);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(new Color(240, 240, 240));
        label.setFont(new Font("Serif", Font.PLAIN, 23));
        label.setIconTextGap(-25);
        label.setOpaque(true);
        label.setBorder(border);
        //panel.add(label);

        myButton = new JButton("Register");
        myButton.setBounds(100, 300, 200, 50);
        myButton.setFocusable(false);

        myButton1 = new JButton("Login");
        myButton1.setBounds(300, 300, 200, 50);
        myButton1.setFocusable(false);

        label.add(myButton);
        label.add(myButton1);

        //Adding the components to the container


        con.add(label);


        //Making the container a Flow Layout
        con.setLayout(new FlowLayout());

        buttonActions();

        pack();
        setVisible(true);
        setSize(580,430);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void buttonActions() {
        myButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new RegisterDemo();
            }
        });

        myButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginDemo();
            }
        });


    }
}

