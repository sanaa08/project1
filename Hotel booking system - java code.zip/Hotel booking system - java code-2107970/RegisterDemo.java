import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

class RegisterDemo extends JFrame {

    private JTextField txtFirstname;
    private JTextField txtLastname;
    private JTextField txtUEmail;
    private JTextField txtMobileNo;
    private JPasswordField txtPass;
    private JTextField txtAddress1;

    private JLabel lblFirstname;
    private JLabel lblLastname;
    private JLabel lblUEmail;
    private JLabel lblMobileNo;
    private JLabel lblPass;
    private JLabel lblAddress1;

    private JButton btnReg;
    private JButton btnBack;

    private Database database;

    /**
     * Constructor for objects of class Login
     */


    JLabel label = new JLabel();
    JPanel panel = new JPanel();
    public RegisterDemo() {

        //setLayout(new FlowLayout());
        //Container con = getContentPane();

        //label.setBackground(new Color(100, 200, 255));
        Border border = BorderFactory.createLineBorder(Color.white, 8);
        label.setBorder(border);

        label.setBounds(0, 0, 100, 50);
        label.setFont(new Font(null, Font.PLAIN, 25));
        //con.add(label);



       database = new Database();

        txtFirstname = new JTextField(20);
        txtFirstname.setBounds(100, 20, 100, 20);


        txtAddress1 = new JTextField(20);
        txtAddress1.setBounds(100, 80, 100, 20);

        txtLastname = new JTextField(20);
        txtLastname.setBounds(100, 50, 100, 20);

        txtUEmail = new JTextField(20);
        txtUEmail.setBounds(100, 110, 100, 20);


        txtMobileNo = new JTextField(20);
        txtMobileNo.setBounds(100, 140, 100, 20);

        txtPass = new JPasswordField(20);
        txtPass.setBounds(100, 170, 100, 20);

        //Creating new JButton objects and values
        btnReg = new JButton("Register");
        btnReg.setBounds(200, 250, 150, 50);
        btnReg.setFocusable(false);

        btnBack = new JButton("Back");
        btnBack.setBounds(300, 250, 150, 50);
        btnBack.setFocusable(false);

        lblFirstname = new JLabel("First Name:");
        lblFirstname.setBounds(20, 10, 100, 40);
        lblFirstname.setForeground(Color.black);

        lblLastname = new JLabel("Last Name");
        lblLastname.setBounds(20, 10, 100, 100);
        lblLastname.setForeground(Color.black);

        lblUEmail = new JLabel("EMail");
        lblUEmail.setBounds(20, 10, 100, 220);
        lblUEmail.setForeground(Color.black);

        lblMobileNo = new JLabel("MobileNo");
        lblMobileNo.setBounds(20, 10, 100, 280);
        lblMobileNo.setForeground(Color.black);

        lblPass = new JLabel("Password");
        lblPass.setBounds(20, 10, 100, 340);
        lblPass.setForeground(Color.black);

        lblAddress1 = new JLabel("Address1");
        lblAddress1.setBounds(20, 10, 100, 160);
        lblAddress1.setForeground(Color.black);

        //Creating a container for the components
        Container con = getContentPane();
        con.setBackground(new Color(100, 200, 255));

        con.add(lblFirstname);
        con.add(txtFirstname);
        con.add(lblLastname);
        con.add(txtLastname);
        con.add(lblUEmail);
        con.add(txtUEmail);
        con.add(lblMobileNo);
        con.add(txtMobileNo);
        con.add(lblPass);
        con.add(txtPass);
        con.add(lblAddress1);
        con.add(txtAddress1);

        con.add(btnReg);
        con.add(btnBack);

        setLayout(new FlowLayout());

        //Calling the buttonActions() method
        buttonActions();

        pack();
        setVisible(true);
        setSize(280,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }


    //buttonActions() method
    private void buttonActions() {
        btnReg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = "INSERT INTO customer(Title, FirstName, Lastname, EMail, MobileNo, Password,Address1,) "
                        + "VALUES ('" + txtFirstname.getText() + "', '" +
                        txtLastname.getText() + "', '" + txtUEmail.getText() + "', '" + txtMobileNo.getText() + "', '" + txtPass.getText() + "', '" + txtAddress1.getText() + "',);";


                try {
                    database.statement.executeUpdate(query);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, "You have successfully registered!");

                dispose();
                new LoginDemo();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new launchPageDemo();
            }
        });

    }
}
