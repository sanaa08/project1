import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

class MakeBooking extends JFrame {
    private DefaultListModel<String> roomItems;
    private JList<String> roomList;

    private JButton bookRoom;
    private JButton backBtn;

    private JLabel arrivalDate;
    private JLabel departureDate;
    private JLabel roomtype;
    private JLabel roomnumber;
    private JLabel floornum;
    private JLabel numofguests;

    private JTextField aDate;
    private JTextField dDate;
    private JTextField rtype;
    private JTextField rnumber;
    private JTextField fnum;
    private JTextField nguests;

    private Integer customerId;

    private Database database;

    MakeBooking() {
        setLayout(new FlowLayout());
        this.customerId = customerId;
        database = new Database();

        roomItems = new DefaultListModel<>();
        roomList = new JList<>(roomItems);
        JScrollPane listScroll = new JScrollPane(roomList);
        listScroll.setPreferredSize(new Dimension(250, 80));
        listScroll.setBackground(Color.black);
        listScroll.setForeground(Color.white);

        bookRoom = new JButton("Book Room");
        backBtn = new JButton("Back");


        arrivalDate = new JLabel("Enter Arrival Date");
        departureDate = new JLabel("Enter Departure Date");
        roomtype = new JLabel("Enter room type");
        roomnumber = new JLabel("Enter room number");
        floornum = new JLabel("Enter floor number");
        numofguests = new JLabel("Enter number of guests");

        aDate = new JTextField(10);
        dDate = new JTextField(10);
        rtype = new JTextField(10);
        rnumber = new JTextField(10);
        fnum = new JTextField(10);
        nguests = new JTextField(10);

        Container con = getContentPane();
        //Making the container a Flow Layout
        con.setBackground(new Color(100, 200, 255));
        con.setLayout(new FlowLayout());

        con.add(arrivalDate);
        arrivalDate.setForeground(Color.black);
        con.add(aDate);
        con.add(departureDate);
        departureDate.setForeground(Color.black);
        con.add(dDate);
        con.add(roomtype);
        con.add(rtype);
        con.add(roomnumber);
        con.add(rnumber);
        con.add(floornum);
        con.add(fnum);
        con.add(numofguests);
        con.add(nguests);


        con.add(bookRoom);
        add(backBtn);

        buttonActions();
        getRooms();

        pack();
        setVisible(true);
        setSize(880,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void buttonActions() {
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new CustomerPage();
            }
        });

        roomList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                String listItem = roomList.getSelectedValue();
                int roomId = Integer.parseInt(listItem.split("-")[0].trim());

                try {
                    String query = "SELECT * FROM `room` WHERE `roomid` = " + roomId;
                    database.statement = database.conn.createStatement();
                    database.resultSet = database.statement.executeQuery(query);

                    while (database.resultSet.next()) {
                        String roomid = "RoomID: " + database.resultSet.getString("roomid") + "\n";
                        String roomtype = "Room Type: " + database.resultSet.getString("roomtype") + "\n";
                        String floorlevel = "Floor Level: " + database.resultSet.getString("floorlevel") + "\n";


                        JOptionPane.showMessageDialog(null, roomid + roomtype + floorlevel);

                    }
                } catch (SQLException s) {
                    s.printStackTrace();
                }
            }
        });

        bookRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Confirm booking");
                dispose();
                new CustomerPage();
            }
        });
        String listItem = roomList.getSelectedValue();
                int roomId = Integer.parseInt(listItem.split("-")[0].trim());
                String arrivalDate = aDate.getText();
                String departureDate =dDate.getText();
                int manager_id = 1;
                String booking_status = "Pending";
                String payment_status = "";

                try {

                    String query = "INSERT INTO booking (customerid, roomid, managerid, arrivaldate, departuredate, bookingstatus, paid) " +
                            "VALUES ('" + customerId + "', '" + roomId + "', '" + manager_id + "', '" + arrivalDate + "', '" + departureDate + "', '" + booking_status + "', '" + payment_status + "')";
                    database.statement = database.conn.createStatement();
                    database.statement.executeUpdate(query);

                } catch (SQLException s) {
                    s.printStackTrace();
                }

            }

    public void getRooms() {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date cDate = new Date(System.currentTimeMillis());
            String currentDate = dateFormat.format(cDate); // Process to get current date in YYYY-MM-DD format

            String query = "SELECT * FROM room";
            database.statement = database.conn.createStatement();
            database.resultSet = database.statement.executeQuery(query);

            while (database.resultSet.next()) {
                String roomId = database.resultSet.getString("roomid");
                String roomtype = database.resultSet.getString("roomtype");

                roomItems.addElement(roomId + " - " + roomtype);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

