import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

class ViewBookings extends JFrame {
    private DefaultListModel<String> bookingItems;
    private JList<String> bookingsList;


    private JLabel email;
    private JButton deleteBtn;
    private JButton backBtn;
    private JLabel lblpic0;
    ImageIcon icon0;

    private JTextField cemail;
    private Integer customerId;

    private String roomId;
    private String role;
    private Database database;

    ViewBookings() {
        setLayout(new FlowLayout());

        this.customerId = customerId;
        this.role = role;
        database = new Database();

        //Creating a container for the components
        Container con = getContentPane();
        //Making the container a Flow Layout
        con.setBackground(new Color(100, 200, 255));
        con.setLayout(new FlowLayout());
        bookingItems = new DefaultListModel<>();
        bookingsList = new JList<>(bookingItems);
        JScrollPane listScroll = new JScrollPane(bookingsList);
        listScroll.setPreferredSize(new Dimension(250, 80));
        listScroll.setBackground(Color.black);
        listScroll.setForeground(Color.white);

        email = new JLabel("Customer email");
        cemail = new JTextField(20);

        deleteBtn = new JButton("Check Booking");
        backBtn = new JButton("Back");
        icon0 = new ImageIcon("/Users/sanatabaku/IdeaProjects/HBSdemo/src/images.jpeg");
        lblpic0 = new JLabel();

        lblpic0.setIcon(icon0);
        lblpic0.setSize(400,200);

        con.add(listScroll);

        con.add(email);
        con.add(cemail);
        con.add(deleteBtn);

        con.add(backBtn);
        con.add(lblpic0);

        buttonActions();
        getBookings();

        pack();
        setVisible(true);
        setSize(350,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void buttonActions() {
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new CustomerPage();
            }
        });
        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Your booking is available");


            }
        });

        bookingsList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                try {
                    String listItem = bookingsList.getSelectedValue();
                    int roomId = Integer.parseInt(listItem.split("-")[1].trim());

                    String query = "SELECT * FROM room WHERE `RoomID` = " + roomId;

                    database.statement = database.conn.createStatement();
                    database.resultSet = database.statement.executeQuery(query);

                    while (database.resultSet.next()) {
                        String roomid = "RoomID: " + database.resultSet.getString("RoomID") + "\n";
                        String roomtype = "Room Type: " + database.resultSet.getString("RoomType") + "\n";
                        String floorlevel = "Floor Number: " + database.resultSet.getString("Floornum") + "\n";


                        JOptionPane.showMessageDialog(null, roomid + roomtype + floorlevel);
                    }
                }
                catch (SQLException s) {
                    s.printStackTrace();
                }
                catch (NullPointerException e1) {

                }
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String listItem = bookingsList.getSelectedValue();

                int bookingId = Integer.parseInt(listItem.split("-")[0].trim());
                try {
                    String query = "DELETE FROM booking WHERE BookingID = " + bookingId;
                    database.statement.executeUpdate(query);

                    bookingItems.removeAllElements();
                    getBookings();
                } catch (SQLException s) {
                    s.printStackTrace();
                }
            }
        });
    }

    public void getBookings() {
        try {
            ArrayList<Integer> bookingIDs = new ArrayList<Integer>();
            ArrayList<Integer> roomIDs = new ArrayList<Integer>();

            String query = "SELECT * FROM booking WHERE  CustomerID = " + customerId;

            database.statement = database.conn.createStatement();
            database.resultSet = database.statement.executeQuery(query);

            while (database.resultSet.next()) {
                int bookingId = database.resultSet.getInt(1);
                int roomId = database.resultSet.getInt(3);

                bookingIDs.add(bookingId);
                roomIDs.add(roomId);
            }

            for (int i = 0; i < bookingIDs.size(); i ++) {
                query = "SELECT * FROM room WHERE RoomID = " + roomIDs.get(i);
                database.statement = database.conn.createStatement();
                database.resultSet = database.statement.executeQuery(query);

                while (database.resultSet.next()) {
                    bookingItems.addElement(bookingIDs.get(i) + " - " + roomIDs.get(i) + " - " + database.resultSet.getString("roomtype"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


